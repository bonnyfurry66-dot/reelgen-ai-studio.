const { createClient } = require("@supabase/supabase-js");

const COOKIE_ACCESS = "rg_access";
const COOKIE_REFRESH = "rg_refresh";

function send(res, status, payload) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(payload));
}

function readCookies(req) {
  const raw = req.headers.cookie || "";
  return Object.fromEntries(
    raw.split(";").map((part) => {
      const i = part.indexOf("=");
      if (i < 0) return ["", ""];
      return [part.slice(0, i).trim(), decodeURIComponent(part.slice(i + 1).trim())];
    }).filter(([key]) => key)
  );
}

function writeSessionCookies(res, session) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  const maxAge = Math.max(60, Number(session.expires_in || 3600));
  res.setHeader("Set-Cookie", [
    `${COOKIE_ACCESS}=${encodeURIComponent(session.access_token)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${maxAge}${secure}`,
    `${COOKIE_REFRESH}=${encodeURIComponent(session.refresh_token)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=2592000${secure}`
  ]);
}

function clearSessionCookies(res) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader("Set-Cookie", [
    `${COOKIE_ACCESS}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${secure}`,
    `${COOKIE_REFRESH}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${secure}`
  ]);
}

function supabasePublic() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error("Missing SUPABASE_URL or SUPABASE_ANON_KEY in Vercel.");
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
  });
}

function supabaseAdmin() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in Vercel.");
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
  });
}

async function getAuthenticatedUser(req, res) {
  const cookies = readCookies(req);
  if (!cookies[COOKIE_ACCESS] || !cookies[COOKIE_REFRESH]) return null;

  const client = supabasePublic();
  const { data, error } = await client.auth.setSession({
    access_token: cookies[COOKIE_ACCESS],
    refresh_token: cookies[COOKIE_REFRESH]
  });
  if (error || !data.session) return null;

  const { data: userData, error: userError } = await client.auth.getUser();
  if (userError || !userData.user) return null;

  const { data: current } = await client.auth.getSession();
  if (current && current.session) writeSessionCookies(res, current.session);
  return userData.user;
}

function getBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  return {};
}

async function generateStory(body) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY is missing from Vercel Environment Variables.");

  const prompt = String(body.prompt || body.description || body.idea || "").trim();
  if (!prompt) {
    const error = new Error("Enter a story idea or prompt first.");
    error.status = 400;
    throw error;
  }

  const style = String(body.style || "Animated Movie");
  const duration = Math.min(180, Math.max(15, Number(body.duration || 60)));
  const language = String(body.language || "English");
  const voice = String(body.voice || body.narrator || "female");

  const instruction = [
    "You are the professional story writer inside ReelGen AI Studio.",
    "Create an original, engaging short-form video story based on the user's idea.",
    `Visual style: ${style}. Target duration: ${duration} seconds.`,
    `Language: ${language}. Narration preference: ${voice}.`,
    "Return valid JSON only with exactly these keys: title, logline, script, scenes.",
    "title must be short. logline must be one sentence. script must be narration/dialogue text.",
    "scenes must be an array of 3 to 8 objects, each with title, visual, dialogue.",
    "Keep dialogue and narration in the requested language. Do not include markdown fences.",
    `User idea: ${prompt}`
  ].join("\n");

  const response = await fetch(
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": key
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: instruction }] }],
        generationConfig: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "OBJECT",
            properties: {
              title: { type: "STRING" },
              logline: { type: "STRING" },
              script: { type: "STRING" },
              scenes: {
                type: "ARRAY",
                items: {
                  type: "OBJECT",
                  properties: {
                    title: { type: "STRING" },
                    visual: { type: "STRING" },
                    dialogue: { type: "STRING" }
                  },
                  required: ["title", "visual", "dialogue"]
                }
              }
            },
            required: ["title", "logline", "script", "scenes"]
          }
        }
      })
    }
  );

  const result = await response.json();
  if (!response.ok) {
    const message = result && result.error && result.error.message
      ? result.error.message
      : "Gemini could not generate the story.";
    const error = new Error(message);
    error.status = response.status === 429 ? 429 : 502;
    throw error;
  }

  const text = result?.candidates?.[0]?.content?.parts
    ?.map((part) => part.text || "")
    .join("")
    .trim();

  if (!text) throw new Error("Gemini returned an empty story. Please try again.");
  let story;
  try {
    story = JSON.parse(text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, ""));
  } catch {
    throw new Error("Gemini returned a response we could not read. Please try again.");
  }

  return {
    title: String(story.title || "Untitled story"),
    logline: String(story.logline || ""),
    script: String(story.script || ""),
    scenes: Array.isArray(story.scenes) ? story.scenes : []
  };
}

module.exports = async function handler(req, res) {
  try {
    const pathname = new URL(req.url, "https://reelgen.local").pathname
      .replace(/\/+$/, "") || "/";
    const method = req.method || "GET";
    const body = getBody(req);

    if (pathname === "/api/health" && method === "GET") {
      return send(res, 200, {
        ok: true,
        service: "ReelGen API",
        configured: {
          supabase: Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY),
          gemini: Boolean(process.env.GEMINI_API_KEY),
          videoProvider: Boolean(process.env.VIDEO_PROVIDER_API_KEY)
        }
      });
    }

    if (pathname === "/api/auth/register" && method === "POST") {
      const email = String(body.email || "").trim();
      const password = String(body.password || "");
      if (!email || password.length < 8) {
        return send(res, 400, { error: "Enter a valid email and a password of at least 8 characters." });
      }
      const client = supabasePublic();
      const { data, error } = await client.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: `${req.headers["x-forwarded-proto"] || "https"}://${req.headers.host}/` }
      });
      if (error) return send(res, 400, { error: error.message });
      if (data.session) writeSessionCookies(res, data.session);
      return send(res, 200, {
        user: data.user,
        requiresEmailConfirmation: !data.session,
        message: data.session
          ? "Account created. You are signed in."
          : "Account created. Check your email to confirm your account before logging in."
      });
    }

    if (pathname === "/api/auth/login" && method === "POST") {
      const email = String(body.email || "").trim();
      const password = String(body.password || "");
      const client = supabasePublic();
      const { data, error } = await client.auth.signInWithPassword({ email, password });
      if (error) return send(res, 401, { error: error.message });
      if (data.session) writeSessionCookies(res, data.session);
      return send(res, 200, { user: data.user, message: "Signed in successfully." });
    }

    if (pathname === "/api/auth/logout" && method === "POST") {
      clearSessionCookies(res);
      return send(res, 200, { ok: true, message: "Signed out." });
    }

    if (pathname === "/api/auth/me" && method === "GET") {
      const user = await getAuthenticatedUser(req, res);
      if (!user) return send(res, 401, { error: "Not signed in." });
      return send(res, 200, { user });
    }

    if (pathname === "/api/story" && method === "POST") {
      const user = await getAuthenticatedUser(req, res);
      if (!user) return send(res, 401, { error: "Please sign in before generating a story." });
      const story = await generateStory(body);
      return send(res, 200, story);
    }

    if (pathname === "/api/videos" && method === "GET") {
      const user = await getAuthenticatedUser(req, res);
      if (!user) return send(res, 401, { error: "Please sign in to view your library." });
      const admin = supabaseAdmin();
      const { data, error } = await admin
        .from("videos")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) return send(res, 500, { error: error.message });
      const videos = (data || []).map((item) => ({
        id: item.id,
        prompt: item.prompt,
        title: item.title || item.prompt || "Untitled video",
        style: item.style,
        duration: item.duration,
        quality: item.quality,
        status: item.status,
        progress: item.progress,
        downloadUrl: item.download_url || null,
        url: item.download_url || null
      }));
      return send(res, 200, { videos });
    }

    if (pathname.startsWith("/api/videos/") && method === "GET") {
      const user = await getAuthenticatedUser(req, res);
      if (!user) return send(res, 401, { error: "Please sign in to view this video." });
      const id = decodeURIComponent(pathname.slice("/api/videos/".length));
      const admin = supabaseAdmin();
      const { data, error } = await admin
        .from("videos")
        .select("*")
        .eq("id", id)
        .eq("user_id", user.id)
        .maybeSingle();
      if (error) return send(res, 500, { error: error.message });
      if (!data) return send(res, 404, { error: "Video not found." });
      return send(res, 200, {
        id: data.id,
        prompt: data.prompt,
        title: data.title || data.prompt || "Untitled video",
        style: data.style,
        duration: data.duration,
        quality: data.quality,
        status: data.status,
        progress: data.progress,
        downloadUrl: data.download_url || null,
        url: data.download_url || null
      });
    }

    if (pathname === "/api/videos" && method === "POST") {
      const user = await getAuthenticatedUser(req, res);
      if (!user) return send(res, 401, { error: "Please sign in before generating a video." });
      return send(res, 503, {
        error: "Video rendering is not connected yet. Your account and story tools can work, but ReelGen still needs a video-generation provider."
      });
    }

    return send(res, 404, { error: "ReelGen API route not found." });
  } catch (error) {
    const status = Number(error.status) || 500;
    return send(res, status, {
      error: error.message || "Unexpected ReelGen server error."
    });
  }
};
